jQuery(document).ready(function(){
	jQuery(".amader-slider").owlCarousel({
		'autoPlay' : 3000,
		'items' : 3,		
		'itemsDesktop' : [1200, 3],
		'itemsDesktopSmall' : [1000, 3],
		'itemsTablet' : [768, 3],
		'stopOnHover' : true,
	});
	
	jQuery(".full-slider .prev").click(function(){
		jQuery(".amader-slider").trigger('owl.prev');		
		return false;
	});

	jQuery(".full-slider .next").click(function(){
		jQuery(".amader-slider").trigger('owl.next');		
		return false;
	});
	
});