jQuery(document).ready(function(){
	jQuery(".amader-slider").owlCarousel({
		'autoPlay' : 3000,
		'items' : 5,
		'itemsDesktop' : [1200, 5],
		'itemsDesktopSmall' : [1000, 4],
		'itemsTablet' : [768, 3],
		'stopOnHover' : true,
	});
	

});